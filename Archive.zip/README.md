# cos226-prac1
This assignment is meant to act as a step-by-step tutorial on the functioning of Java threads. Please read through the tutorial carefully as this will be the only material provided on the basics of multithreaded programming. From here on forward, the practical assignments will assume that you know how threads work.
